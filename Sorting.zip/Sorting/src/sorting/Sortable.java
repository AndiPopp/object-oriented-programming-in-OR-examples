package sorting;

public interface Sortable {
	
	public double sortValue();
}

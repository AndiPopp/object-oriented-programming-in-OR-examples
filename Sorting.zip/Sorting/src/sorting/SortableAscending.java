package sorting;

public interface SortableAscending extends Sortable {}

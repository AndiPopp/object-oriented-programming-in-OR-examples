package graphs.weighted;

import graphs.*;

public class WeightedGraph extends Graph {

	public WeightedGraph(Node[] nodes, WeightedEdge[] edges) {
		super(nodes, edges);
	}
}
